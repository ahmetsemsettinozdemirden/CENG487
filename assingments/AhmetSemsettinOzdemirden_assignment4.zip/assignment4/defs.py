# CENG 487 Assignment4 by
# Ahmet Semsettin Ozdemirden
# StudentNo: 230201043
# Date: 05-2019
ESCAPE = '\033'

class DrawStyle:
	NODRAW = 0
	VERTEX = 1
	WIRE = 2
	FACETED = 3
	SMOOTH = 4


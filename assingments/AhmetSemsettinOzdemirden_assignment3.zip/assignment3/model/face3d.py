# CENG 487 Assignment3 by
# Ahmet Semsettin Ozdemirden
# StudentNo: 230201043
# Date: 04-2019

class Face3D(object):

    def __init__(self, vertices, color):
        self.vertices = vertices
        self.color = color